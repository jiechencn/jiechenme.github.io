$(function(){
	$(".myHat").click(function(){
		$("body").toggleClass("snowBG");	
	});
});
