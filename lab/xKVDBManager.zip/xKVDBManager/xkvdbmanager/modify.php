<?php
require_once("../common/lib/util.php");

$pKey = rmHtmlTag($_POST['key']);
$pKeys = rmHtmlTag($_POST['keys']);
$pValue = rmHtmlTag($_POST['value']);
$pAction = rmHtmlTag($_POST['action']);


$kv = new SaeKV();
$ret = $kv->init();

if ($pAction=='delete'){
	for($x=0;$x<count($pKeys);$x++) {
		$ret = $kv->delete($pKeys[$x]);
		//echo $pKeys[$x];
	}
}else{
	// modify
	if ($pKey==""){
		echo "Error: null key";
		die();
	}else{
		$kv->delete($pKey);
		$ret = $kv->add($pKey, $pValue);
	}
}


if ($ret) 
	echo "success";
else
	echo $kv->errmsg(); 

?>