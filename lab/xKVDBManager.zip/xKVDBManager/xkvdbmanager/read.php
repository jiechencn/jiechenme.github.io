<?php
require_once("../common/lib/util.php");

$pKey = rmHtmlTag($_GET['key']);

$allKeyValue = array();

$kv = new SaeKV();
$ret = $kv->init();

$ret = $kv->pkrget($pKey, 100);
while (true) {
	array_push($allKeyValue, $ret);	
	end($ret);
	$start_key = key($ret);
	$i = count($ret);
	if ($i < 100) break;
	$ret = $kv->pkrget($pKey, 100, $start_key);
}

echo json_encode($allKeyValue);
?>