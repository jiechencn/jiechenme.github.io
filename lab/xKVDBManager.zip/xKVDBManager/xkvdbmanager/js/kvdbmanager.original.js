var $xinfo=jQuery.noConflict();

$xinfo("document").ready(function(){
	
	var mCount = 0;
	init();
	
	$xinfo("#idBtnSearch").click(function(){
		var key = $xinfo('#idInputKey').val();
		$xinfo('#idInputValue').val("");
		
		$xinfo.ajax({
			type:"get",
			url:"read.php",
			data:{"key":key, "random":Math.random},
			dataType:"json",
			beforeSend:function(){
				showMessageBox(1, '正在查询……');
			},
			complete: function(){
				hideMessageBox();
			},
			success: function(dd){
				$xinfo('#idTableResult').remove();
				createResultTableHeader(true);
				var i = 0;
				$xinfo.each(dd, function(k,v){  
					for (var one in v){  
						createResultTableContent(++i, one, v[one]);
					}  
				});  
				mCount = i;
				createResultTableHeader(false);
			},
			error:function(msg){
				showMessageBar(3, msg.status + "-" + msg.statusText);
			}
		});
		
	});
	
	$xinfo("#idBtnModify").click(function(){
		var key = $xinfo('#idInputKey').val();
		var value = $xinfo('#idInputValue').val();
		key = key.trim();
		if (key==""){
			alert("请输入Key");
			$xinfo('#idInputKey').val("")
			return;
		}
		
		$xinfo.ajax({
			type:"post",
			url:"modify.php",
			data:{"key":key, "value":value, "action":"modify"},
			dataType:"text",
			success:function(dd){
				if (dd=="success"){
					showMessageBar(0, "Added/Modified successfully");
				}else{
					showMessageBar(3, dd);
				}
			},
			error:function(msg){
				showMessageBar(3, msg.status + "-" + msg.statusText);
				createResultTableHeader(true);
				createResultTableContent(1, "key1", "key1");
				createResultTableContent(2, "key2", "key2");
				createResultTableContent(3, "key3", "key3");
				createResultTableContent(4, "key4", "key4");
				createResultTableContent(5, "key5", "key5");
				createResultTableHeader(false);
			}
		});
	});
	
	$xinfo("#idBtnDelete").click(function(){
		var dropKeys = new Array();
		var $check_boxes = $xinfo("input[type='checkbox']:checked");
		if($check_boxes.length<=0){ 
			alert('先选择要删除的行，再点删除。');
			return;
		}  
		$check_boxes.each(function(){  
			dropKeys.push($xinfo(this).val());  
		});  
	
		$xinfo.ajax({
			type:"post",
			url:"modify.php",
			data:{"keys":dropKeys, "action":"delete"},
			dataType:"text",
			success:function(dd){
				if (dd=="success"){
					showMessageBar(0, "Deleted successfully");
					$xinfo('#idInputKey').val("");		
					$xinfo('#idInputValue').val("");		
				}else{
					showMessageBar(3, dd);
				}
			},
			error:function(msg){
				showMessageBar(3, msg.status + "-" + msg.statusText);
			}
		});
	});
	
	function createResultTableHeader(isHead){
		if (isHead){
			var ele = "<table class='table table-hover' id='idTableResult'>";
			ele = ele + "<thead>";
			ele = ele + "<tr>";
			ele = ele + "<th class='smsThTime'>No.</th>";
			ele = ele + "<th class='smsThSender'>Key</th>";
			ele = ele + "<th>Value</th>";
			ele = ele + "</tr>";
			ele = ele + "</thead>";
			ele = ele + "<tbody id='idTbodyContent'>";
			$xinfo('#idDivResult').append(ele);
		}else{
			var ele = "<tr>";
			ele = ele + "<td colspan='2'>共 <kbd>" + mCount + "</kbd> 条</td>";
			ele = ele + "<td class='text-right'><kbd>前缀关键字范围太大会影响JS处理速度，建议缩小查询条件</kbd></td>";
			ele = ele + "</tr>";
			$xinfo('#idTbodyContent').append(ele);	
			ele = "</tbody></table>";
			$xinfo('#idDivResult').append(ele);			
		}
	}
	
	function createResultTableContent(idx, key, value){
		var ele = "<tr id='idOneTR" + idx + "'>";
		ele = ele + "<td><input type='checkbox' name='nCheckboxKV' id='idCheckboxKV" + idx + "' value='" + key + "'></td>";
		ele = ele + "<td>" + key + "</td>";
		ele = ele + "<td>" + value + "</td>";
		ele = ele + "</tr>";
		$xinfo('#idTableResult').append(ele);	
		
		var tr = $xinfo("#idOneTR" + idx); 
		tr.click(function(event){
			fillInputForm(key.decodeHTML(), value.decodeHTML());
		});

	}
	
	function fillInputForm(key, value){
		$xinfo('#idInputKey').val(key);
		$xinfo('#idInputValue').val(value);
	}
	
	function init(){
		//
	}

});

